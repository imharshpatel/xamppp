<?php
$name = $email = $position = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $email = $_POST["email"];
    $position = $_POST["position"];
    header("Location: employee_display.php?name=$name&email=$email&position=$position");
    exit();
}
?>

<form method="post">
    <label>Name:</label>
    <input type="text" name="name" value="<?php echo $name; ?>" required><br><br>

    <label>Email:</label>
    <input type="email" name="email" value="<?php echo $email; ?>" required><br><br>

    <label>Position:</label>
    <input type="text" name="position" value="<?php echo $position; ?>" required><br><br>

    <input type="submit" value="Submit">
</form>
