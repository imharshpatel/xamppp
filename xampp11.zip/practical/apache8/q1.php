<?php
$xmlFile = "cricket.xml";

if (!file_exists($xmlFile)) {
    $xml = new SimpleXMLElement("<CricketTeam></CricketTeam>");
} else {
    $xml = simplexml_load_file($xmlFile);
}

$teams = [
    ["country" => "Australia", "player" => "David Warner", "runs" => 7000, "wicket" => 2],
    ["country" => "Australia", "player" => "Steve Smith", "runs" => 8500, "wicket" => 1],
    ["country" => "India", "player" => "Virat Kohli", "runs" => 12000, "wicket" => 4],
    ["country" => "India", "player" => "Rohit Sharma", "runs" => 10000, "wicket" => 0]
];

foreach ($teams as $team) {
    $teamNode = $xml->addChild("Team");
    $teamNode->addAttribute("country", $team["country"]);
    $teamNode->addChild("player", $team["player"]);
    $teamNode->addChild("runs", $team["runs"]);
    $teamNode->addChild("wicket", $team["wicket"]);
}

$xml->asXML($xmlFile);

echo "XML file created/updated successfully!";
?>
