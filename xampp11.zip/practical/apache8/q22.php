<?php
if (isset($_GET["name"]) && isset($_GET["email"]) && isset($_GET["position"])) {
    echo "<h3>Employee Details</h3>";
    echo "Name: " . $_GET["name"] . "<br>";
    echo "Email: " . $_GET["email"] . "<br>";
    echo "Position: " . $_GET["position"] . "<br>";
} else {
    echo "No data received.";
}
?>
