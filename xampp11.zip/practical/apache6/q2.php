<?php
class Calculator {
    public $num1;
    public $num2;

    public function __construct($a, $b) {
        $this->num1 = $a;
        $this->num2 = $b;
    }

    public function add() {
        return $this->num1 + $this->num2;
    }

    public function subtract() {
        return $this->num1 - $this->num2;
    }

    public function multiply() {
        return $this->num1 * $this->num2;
    }

    public function divide() {
        if ($this->num2 != 0) {
            return $this->num1 / $this->num2;
        } else {
            return "Cannot divide by zero";
        }
    }
}

$calc = new Calculator(10, 5);
echo "Addition: " . $calc->add() . "<br>";
echo "Subtraction: " . $calc->subtract() . "<br>";
echo "Multiplication: " . $calc->multiply() . "<br>";
echo "Division: " . $calc->divide();
?>
