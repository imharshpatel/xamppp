<?php
class Article {
    public $articleid;
    public $name;
    public $articleqty;
    public $price;

    public function __construct($id, $name, $qty, $price) {
        $this->articleid = $id;
        $this->name = $name;
        $this->articleqty = $qty;
        $this->price = $price;
    }

    public function display() {
        echo "ID: $this->articleid, Name: $this->name, Qty: $this->articleqty, Price: $this->price <br>";
    }
}

$articles = [
    new Article(1, "Notebook", 30, 200),
    new Article(2, "Pen", 100, 50),
    new Article(3, "Bag", 20, 700),
    new Article(4, "Shoes", 60, 1200),
];

echo "1. Display all articles<br>";
foreach ($articles as $article) {
    $article->display();
}

echo "<br>2. Articles with price > 500<br>";
foreach ($articles as $article) {
    if ($article->price > 500) {
        $article->display();
    }
}

echo "<br>3. Articles with quantity > 50<br>";
foreach ($articles as $article) {
    if ($article->articleqty > 50) {
        $article->display();
    }
}
?>
