<?php
$xmlFile = 'breakfast.xml';

if (!file_exists($xmlFile)) {
    $xml = new SimpleXMLElement('<breakfast_menu/>');

    $food = $xml->addChild('food');
    $food->addChild('name', 'French Fries');
    $food->addChild('price', 'Rs.45');
    $food->addChild('calories', '650');

    $xml->asXML($xmlFile);
}


$xml = simplexml_load_file($xmlFile);


$foods = [
    ["name" => "Pancakes", "price" => "Rs.70", "calories" => "500"],
    ["name" => "Omelette", "price" => "Rs.50", "calories" => "300"],
    ["name" => "Apple Juice", "price" => "Rs.40", "calories" => "120"],
    ["name" => "Orange Juice", "price" => "Rs.50", "calories" => "150"]
];

foreach ($foods as $item) {
    $food = $xml->addChild('food');
    $food->addChild('name', $item["name"]);
    $food->addChild('price', $item["price"]);
    $food->addChild('calories', $item["calories"]);
}


$xml->asXML($xmlFile);

echo "Updated breakfast.xml file successfully!";
?>
