<?php

class Car {
    public $brand = "Toyota";
    public $model = "Camry";
    private $price = 30000;

    public function start() {
        return "Car started";
    }

    public function stop() {
        return "Car stopped";
    }
}


$classes = get_declared_classes();
echo "Declared Classes: ";
print_r($classes);
echo "<br><br>";


$car = new Car();


$methods = get_class_methods('Car');
echo "Methods in Car Class: ";
print_r($methods);
echo "<br><br>";


$properties = get_class_vars('Car');
echo "Properties in Car Class: ";
print_r($properties);
?>
