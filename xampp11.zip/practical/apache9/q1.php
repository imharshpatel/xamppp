<?php
session_start();

if (!isset($_SESSION["stack"])) {
    $_SESSION["stack"] = [];
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["push"])) {
        $value = $_POST["value"];
        if ($value !== "") {
            array_push($_SESSION["stack"], $value);
        }
    } elseif (isset($_POST["pop"])) {
        array_pop($_SESSION["stack"]);
    } elseif (isset($_POST["clear"])) {
        $_SESSION["stack"] = [];
    }
}
?>

<form method="post">
    <label>Enter value to push:</label>
    <input type="text" name="value">
    <input type="submit" name="push" value="Push"><br><br>

    <input type="submit" name="pop" value="Pop">
    <input type="submit" name="clear" value="Clear Stack"><br><br>
</form>

<h3>Stack Contents:</h3>
<?php
if (!empty($_SESSION["stack"])) {
    foreach (array_reverse($_SESSION["stack"]) as $item) {
        echo $item . "<br>";
    }
} else {
    echo "Stack is empty.";
}
?>
