<?php
$result = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $num = $_POST["number"];
    if ($num !== "") {
        $reverse = strrev($num);
        if ($num == $reverse) {
            $result = "$num is a Palindrome.";
        } else {
            $result = "$num is NOT a Palindrome.";
        }
    }
}
?>

<form method="post">
    <label>Enter a number:</label>
    <input type="text" name="number" required>
    <input type="submit" value="Check">
</form>

<h3><?php echo $result; ?></h3>
