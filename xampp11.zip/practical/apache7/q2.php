<?php
$name = $email = $course = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $email = $_POST["email"];
    $course = $_POST["course"];
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    echo "<h3>Student Information</h3>";
    echo "Name: " . $name . "<br>";
    echo "Email: " . $email . "<br>";
    echo "Course: " . $course . "<br>";
}
?>

<form method="post">
    <label>Name:</label>
    <input type="text" name="name" value="<?php echo $name; ?>" required><br><br>

    <label>Email:</label>
    <input type="email" name="email" value="<?php echo $email; ?>" required><br><br>

    <label>Course:</label>
    <select name="course">
        <option value="BBA" <?php if ($course == "BBA") echo "selected"; ?>>BBA</option>
        <option value="BCA" <?php if ($course == "BCA") echo "selected"; ?>>BCA</option>
        <option value="MCA" <?php if ($course == "MCA") echo "selected"; ?>>MCA</option>
    </select><br><br>

    <input type="submit" value="Register">
</form>
