<?php
interface Shape {
    public function area();
    public function volume();
}

class Cylinder implements Shape {
    private $radius;
    private $height;

    public function __construct($r, $h) {
        $this->radius = $r;
        $this->height = $h;
    }

    public function area() {
        return 2 * 3.14 * $this->radius * ($this->radius + $this->height);
    }

    public function volume() {
        return 3.14 * $this->radius * $this->radius * $this->height;
    }
}

$cyl = new Cylinder(5, 10);
echo "Surface Area: " . $cyl->area() . "<br>";
echo "Volume: " . $cyl->volume();
?>
