<?php
$xml = new SimpleXMLElement('<Mayanagari_CD_Store/>');

$classical = $xml->addChild('Classical');
$movie1 = $classical->addChild('Movie');
$movie1->addChild('Name', 'Mughal-e-Azam');
$movie1->addChild('Release_Year', '1960');

$action = $xml->addChild('Action');
$movie2 = $action->addChild('Movie');
$movie2->addChild('Name', 'Sholay');
$movie2->addChild('Release_Year', '1975');

$horror = $xml->addChild('Horror');
$movie3 = $horror->addChild('Movie');
$movie3->addChild('Name', 'Bhoot');
$movie3->addChild('Release_Year', '2003');

file_put_contents('movies.xml', $xml->asXML());
echo "movies.xml file created successfully.";
?>
