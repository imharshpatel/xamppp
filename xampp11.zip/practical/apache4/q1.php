<?php
define("INR_TO_USD", 0.012);
define("INR_TO_GBP", 0.0095);
$result = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $amount = $_POST["amount"];
    $currency = $_POST["currency"];
    
    if (!empty($amount) && is_numeric($amount)) {
        if ($currency == "USD") {
            $converted = $amount * INR_TO_USD;
            $result = "₹$amount INR = \$$converted USD";
        } elseif ($currency == "GBP") {
            $converted = $amount * INR_TO_GBP;
            $result = "₹$amount INR = £$converted GBP";
        }
    } else {
        $result = "Invalid amount";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Currency Converter</title>
</head>
<body>
    <h2>Convert INR to USD or GBP</h2>
    <form method="post">
        <input type="text" name="amount" placeholder="Enter amount">
        <input type="radio" name="currency" value="USD"> USD
        <input type="radio" name="currency" value="GBP"> GBP
        <input type="submit" value="Convert">
    </form>
    <h3><?php echo $result; ?></h3>
</body>
</html>
