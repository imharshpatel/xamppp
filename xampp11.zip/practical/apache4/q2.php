<?php
interface Conversion {
    public function gmToKg($g);
    public function kgToGm($kg);
}

class Convert implements Conversion {
    public function gmToKg($g) {
        return $g / 1000;
    }

    public function kgToGm($kg) {
        return $kg * 1000;
    }
}

$c = new Convert();
echo "5000 grams = " . $c->gmToKg(5000) . " kg<br>";
echo "5 kg = " . $c->kgToGm(5) . " grams";
?>
