<?php
class College {
    protected $collegeName;

    public function __construct($name) {
        $this->collegeName = $name;
    }

    public function getCollegeName() {
        return $this->collegeName;
    }
}

class Department extends College {
    protected $departmentName;

    public function __construct($collegeName, $deptName) {
        parent::__construct($collegeName);
        $this->departmentName = $deptName;
    }

    public function getDepartmentName() {
        return $this->departmentName;
    }
}

class Faculty extends Department {
    private $facultyName;
    private $subject;

    public function __construct($collegeName, $deptName, $facultyName, $subject) {
        parent::__construct($collegeName, $deptName);
        $this->facultyName = $facultyName;
        $this->subject = $subject;
    }

    public function displayInfo() {
        echo "College: " . $this->getCollegeName() . "<br>";
        echo "Department: " . $this->getDepartmentName() . "<br>";
        echo "Faculty Name: " . $this->facultyName . "<br>";
        echo "Subject: " . $this->subject . "<br>";
    }
}

$faculty = new Faculty("XYZ University", "Computer Science", "Dr. John", "Data Structures");
$faculty->displayInfo();
?>
