<?php
$number = "";
$palindrome_result = "";
$reversed_number = "";

function reverseNumber($num) {
    if ($num == "") return "";
    return reverseNumber(substr($num, 1)) . substr($num, 0, 1);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $number = $_POST["number"];

    if (is_numeric($number)) {
        $reversed_number = reverseNumber($number);
        if ($number == $reversed_number) {
            $palindrome_result = "Yes, $number is a Palindrome.";
        } else {
            $palindrome_result = "No, $number is not a Palindrome.";
        }
    } else {
        $palindrome_result = "Enter a valid number.";
    }
}
?>

<form method="post">
    <label>Enter a Number:</label>
    <input type="text" name="number" value="<?php echo htmlspecialchars($number); ?>" required><br><br>
    <input type="submit" value="Check">
</form>

<h3>Palindrome Check:</h3>
<p><?php echo $palindrome_result; ?></p>

<h3>Reversed Number:</h3>
<p><?php echo $reversed_number; ?></p>
