<?php
if (isset($_GET['username'])) {
    $username = trim($_GET['username']);
    
    if ($username == "") {
        echo "Enter username";
    } elseif (strlen($username) < 3) {
        echo "Username is too short";
    } else {
        echo "Valid username";
    }
}
?>
