<?php
$str1 = $str2 = $result = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $str1 = $_POST["string1"];
    $str2 = $_POST["string2"];
    
    if ($str1 === $str2) {
        $result = "Strings match!";
    } else {
        $result = "Strings do NOT match!";
    }
}
?>

<form method="post">
    <label>Enter String 1:</label>
    <input type="text" name="string1" value="<?php echo htmlspecialchars($str1); ?>" required><br><br>

    <label>Enter String 2:</label>
    <input type="text" name="string2" value="<?php echo htmlspecialchars($str2); ?>" required><br><br>

    <input type="submit" value="Check">
</form>

<h3><?php echo $result; ?></h3>
